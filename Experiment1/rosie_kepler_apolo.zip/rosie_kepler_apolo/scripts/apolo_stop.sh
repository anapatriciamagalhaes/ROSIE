#!/usr/bin/env bash
set -euo pipefail
gz topic \
  -t /apolo/apolo_wheel-control/cmd_vel \
  -m gz.msgs.Twist \
  -p "linear: {x: 0.0}, angular: {z: 0.0}"
