#!/usr/bin/env bash
set -euo pipefail

PROJECT="$HOME/rosie_kepler_apolo"
export GZ_SIM_RESOURCE_PATH="$PROJECT/models:${GZ_SIM_RESOURCE_PATH:-}"

gz sim --force-version 8 -v 4 "$PROJECT/worlds/kepler_apolo_home.sdf"
