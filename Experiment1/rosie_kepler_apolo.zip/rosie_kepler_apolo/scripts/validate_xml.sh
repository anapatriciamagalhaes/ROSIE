#!/usr/bin/env bash
set -euo pipefail

WORLD="$HOME/rosie_kepler_apolo/worlds/kepler_apolo_home.sdf"
MODEL="$HOME/rosie_kepler_apolo/models/apolo/model.sdf"

python3 -c "import xml.etree.ElementTree as ET; ET.parse('$WORLD'); ET.parse('$MODEL'); print('XML válido: mundo e robô')"
