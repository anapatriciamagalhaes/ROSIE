#!/usr/bin/env bash
set -euo pipefail

SRC="$(cd "$(dirname "$0")/.." && pwd)"
DST="$HOME/rosie_kepler_apolo"

mkdir -p "$DST/worlds" "$DST/models/apolo" "$DST/config" "$DST/scripts"

cp "$SRC/worlds/kepler_apolo_home.sdf" "$DST/worlds/"
cp "$SRC/models/apolo/model.sdf" "$DST/models/apolo/"
cp "$SRC/models/apolo/model.config" "$DST/models/apolo/"
cp "$SRC/config/"*.yaml "$DST/config/"
cp "$SRC/scripts/"*.sh "$DST/scripts/"
chmod +x "$DST/scripts/"*.sh

echo "Projeto instalado em:"
echo "$DST"
